# Form Dinamis dengan menggunakan Vue.js

* Demo bisa dilihat di https://vuejs.id/example-list-form/
* Video Youtube bisa dilihat di https://youtu.be/FuTu_VFFrOs
